#pragma once
void sort(int*, int, int);
bool ckeckIfSorted(int*, int);
bool checkIfElementsSame(int* prevArr, int* sortedArr, int length);