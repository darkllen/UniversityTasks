public class Edge {
    int l;
    int r;
    int u;
    int d;
    int n;

    public Edge(int n, int l, int r, int u, int d) {
        this.l = l;
        this.r = r;
        this.u = u;
        this.d = d;
        this.n = n;
    }
}
