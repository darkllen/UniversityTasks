#pragma once
int fibonacci(unsigned int n);
int fibonacciWithoutVector(unsigned int n);