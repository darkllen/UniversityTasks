#pragma once
double myPow(double x, int n);
double myQuickPow(double x, int n);
double myPowRecurscion(double x, int n);
double myQuickPowRecurscion(double x, int n);