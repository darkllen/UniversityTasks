import './scss/mainStyles.scss';
//import './scss/errorStyles.scss';
var $ = require("jquery")
console.log(`The time is ${new Date()}`);
